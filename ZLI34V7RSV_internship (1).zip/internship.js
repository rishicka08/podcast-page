const swiper = new Swiper('.swiper', {
    loop: true,
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    slidesPerView: 1,
    spaceBetween: 20,
    breakpoints: {
        576: {
            slidesPerView: 1
        },
        768: {
            slidesPerView: 2
        },
        992: {
            slidesPerView: 3
        },
    }
});
// Function to filter videos based on selected category
document.getElementById('categoryButtons').addEventListener('click', function(event) {
    if (event.target.tagName === 'BUTTON') { // Check if a button was clicked
        const selectedCategory = event.target.getAttribute('data-category');
        const videos = document.querySelectorAll('.video');

        videos.forEach(video => {
            const videoCategory = video.getAttribute('data-category');
            if (selectedCategory === "All" || videoCategory === selectedCategory) {
                video.classList.remove('hidden');
            } else {
                video.classList.add('hidden');
            }
        });
    }
});
// Get elements
const openVideoButton = document.getElementById('openVideoButton');
const videoPopup = document.getElementById('videoPopup');
const closePopup = document.getElementById('closePopup');
const videoIframe = document.getElementById('videoIframe');

// Open video popup
openVideoButton.addEventListener('click', () => {
    videoPopup.style.display = 'flex';
    videoIframe.src += "?autoplay=1"; // Add autoplay
});

// Close video popup
closePopup.addEventListener('click', () => {
    videoPopup.style.display = 'none';
    videoIframe.src = videoIframe.src.replace("?autoplay=1", ""); // Stop video
});